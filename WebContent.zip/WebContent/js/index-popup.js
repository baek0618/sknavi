/**
 * 
 */

$(document).ready(function() {
	$('#make-plan').click(function(e) {
		window.open("make-schedule-popup.html", "a", "width=400, height=300, left=100, top=50"); 
		function showPopup() {
		}
	});

});


